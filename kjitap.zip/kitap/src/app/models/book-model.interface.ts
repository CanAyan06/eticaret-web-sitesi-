export interface BookModel {
    name?: string;
    author?: string;
    year?: string;
    star?: string;
    imageUrl?: string;
    category?: string;
    description?: string;
}